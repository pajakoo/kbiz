<div class="wpbdp-bar">
    <?php wpbdp_the_main_links(); ?>
    <?php wpbdp_the_search_form(); ?>
</div>
