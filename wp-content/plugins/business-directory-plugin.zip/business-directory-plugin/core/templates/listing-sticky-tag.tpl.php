<div class="stickytag">
    <img src="<?php echo WPBDP_URL . 'core/images/featuredlisting.png'; ?>"
         alt="<?php echo _ex( 'Featured Listing', 'templates', 'WPBDM' ); ?>" border="0"
         title="<?php echo _ex( 'Featured Listing', 'templates', 'WPBDM' ); ?>">
</div>
