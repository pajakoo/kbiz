<?php
require_once( WPBDP_PATH . 'core/views/submit_listing.php' );

class WPBDP__Views__Edit_Listing extends WPBDP__Views__Submit_Listing {

}

